#include<iostream>
using namespace std;

class stack
{
	private:
		int a[];
		int top;
		int size;
		
		public:
			stack()
			{
				top=-1;
		    }
		    
		    void setsize(int s)
		    {
		    	size=s;
			}
			
			void push(int d)
			{
				if(top==size-1)
				{
					cout<<"Stack is full"<<endl;
				}
				else
				{
					top++;
					a[top]=d;
				}
			}
			
			void pop()
			{
				if(top==-1)
				{
					cout<<"Stack is empty"<<endl;	
				}
				else
				{
					top--;
				}
			}
			 
			void peak()
			{
				cout<<"The element at top of stack is:"<<" "<<a[top];
				cout<<endl;
			}
			 
		    bool isfull()
		    {
		    	return (top=size-1);
			}
			
			bool isempty()
			{
				return (top=-1);
			}
};


int main()
{
	int n,ch,p;
	
	stack s;
	
	cout<<"Enter the size of stack:";
	cin>>n;
	cout<<endl;
	
	s.setsize(n);
		
	do
	{
		cout<<"1.Push\n2.Pop\n3.Peak\n4.isFull\n5.isEmpty\n6.Exit\nEnter your choice:";
	    cin>>ch;
	    cout<<endl;
	
	
		switch(ch)
		{
		    case 1:
			{
				cout<<"Enter the element to be push:";
				cin>>p;
				cout<<endl;
				s.push(p);
				break;				
			}
			
		    case 2:
		    {
		    	s.pop();
				break;		    	
			}
			
		    case 3:
		    {
		    	s.peak();
		    	break;
			}
			
	        case 4:
		    {
		    	s.isfull();
		    	break;
			}
				
		    case 5:
		    {
		    	s.isempty();
		    	break;
			}
		
		    default:
		    {
			    cout<<"Invalid choice!"<<endl;
			    break;
		    }
	    }
	}while(ch!=6);
}









