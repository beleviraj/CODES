#include<iostream>

using namespace std;

template<typename T>
class Stack
{
	private:
	T *arr;
	const int SIZE;
	int top;
	
	public:
		Stack(int size):SIZE(size)
		{
			arr = new T[SIZE];
			top=-1;
		}
		
		void push(T elements)
		{
			if (top == SIZE - 1) {
            cout << "Stack Overflow!" << endl;
            return;
        }
        arr[++top] = elements;
        cout << "Pushed: " << elements << endl;
		}
		
		T pop()
		{
			 if (top == -1) {
            cout << "Stack Underflow!" << endl;
            return T();  
        }
        return arr[top--];
		}
};

int main()
{
	Stack<int> s1(5);
	s1.push(10);
	s1.push(20);
	cout<<"top element is popped: "<<s1.pop()<<endl;
	
	Stack<char> s2(10);
	s2.push('a');
	s2.push('b');
	s2.push('c');
	cout<<"top character is poped: "<<s2.pop()<<endl;
	return 0;
}