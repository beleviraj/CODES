#include <iostream>
using namespace std;

template<typename T>
bool linearSearch(T arr[], int size, T key) {
    for(int i = 0; i < size; ++i) {
        if(arr[i] == key) {
            return true;
        }
    }
    return false;
}

int main() {
    int size;
    cout << "Enter the size of the array: ";
    cin >> size;
    
    int *intArr = new int[size];
    cout << "Enter the elements of the integer array: ";
    for(int i = 0; i < size; ++i) 
	{
        cin >> intArr[i];
    }
    int intKey;
    cout << "Enter the integer element to search: ";
    cin >> intKey;
    
	float *floatArr = new float[size];
	cout << "Enter the elements of the float array: ";
    for(int i = 0; i < size; ++i) 
	{
        cin >> floatArr[i];
    }
    float floatKey;
    cout << "Enter the float element to search: ";
    cin >> floatKey;

    char *charArr = new char[size];
	cout << "Enter the elements of the char array: ";
    for(int i = 0; i < size; ++i) 
	{
        cin >> charArr[i];
    }
    char charKey;
    cout << "Enter the char element to search: ";
    cin >> charKey;
    
    
     if(linearSearch(intArr, size, intKey)) 
	{
        cout << "Integer element found in the array." << endl;
    } else 
	{
        cout << "Integer element not found in the array." << endl;
    }

    if(linearSearch(floatArr, size, floatKey)) 
	{
        cout << "Float element found in the array." << endl;
    } else 
	{
        cout << "Float element not found in the array." << endl;
    }

    if(linearSearch(charArr, size, charKey)) 
	{
        cout << "Char element found in the array." << endl;
    } else 
	{
        cout << "Char element not found in the array." << endl;
    }

   
    delete[] intArr;
    delete[] floatArr;
    delete[] charArr;

    return 0;

}

    
    
    
   
   

    

    

    

    

    
    
   

