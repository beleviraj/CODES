#include <iostream>
using namespace std;

const int MAX_SIZE = 100;

class Stack {
private:
    int top;
    int arr[MAX_SIZE];

public:
    // Constructor
    Stack() {
        top = -1;
    }

    // Push operation
    void push(int val) {
        if (top == MAX_SIZE - 1) {
            cout << "Stack Overflow\n";
            return;
        }
        arr[++top] = val;
        cout << val << " pushed into stack\n";
    }

    // Pop operation
    int pop() {
        if (top == -1) {
            cout << "Stack Underflow\n";
            return -1;
        }
        return arr[top--];
    }

    // Peek operation
    int display() {
        if (top == -1) {
            cout << "Stack is empty\n";
            return -1;
        }
        return arr[top];
    }

    // Check if the stack is empty
    bool isEmpty() {
        return top == -1;
    }
};

int main() {
    Stack stack;
    int choice, value;

    while (true) {
        cout << "Enter your choice:\n";
        cout << "1. Push\n";
        cout << "2. Pop\n";
        cout << "3. display\n";
        cout << "4. Exit\n";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter value to push: ";
                cin >> value;
                stack.push(value);
                break;
            case 2:
                cout << stack.pop() << " popped from stack\n";
                break;
            case 3:
                cout << "Top element is " << stack.display() << endl;
                break;
            case 4:
                exit(0);
            default:
                cout << "Invalid choice\n";
        }
    }

    return 0;
}
