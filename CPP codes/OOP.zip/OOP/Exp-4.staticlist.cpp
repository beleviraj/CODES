#include <iostream>
#include <string>

using namespace std;


struct Node {
    string productName;
    int productPrice;
    Node* next;
};


class ProductList 
{
	
    private:
    	Node* head;

    public:
    	ProductList() : head(NULL) {}

    
    void insertProduct(const string& name, int price) 
	{
        Node* newNode = new Node;
        newNode->productName = name;
        newNode->productPrice = price;
        newNode->next = NULL;

        if (head == NULL) 
		{
            head = newNode;
        } 
		else 
		{
            Node* temp = head;
            while (temp->next != NULL) 
			{
                temp = temp->next;
            }
            temp->next = newNode;
        }
    }

    
    void displayProducts() {
        Node* temp = head;
        while (temp != NULL) {
            cout << "Product Name: " <<temp->productName<< endl;
            cout<<"Price:"<<temp->productPrice<<endl;
            temp = temp->next;
        }
    }

    
    void deleteProduct(const string& name) {
        Node* temp = head;
        Node* prev = NULL;

        if (temp != NULL&& temp->productName == name) {
            head = temp->next;
            delete temp;
            return;
        }

        while (temp != NULL && temp->productName != name) {
            prev = temp;
            temp = temp->next;
        }

        if (temp == NULL) return;

        prev->next = temp->next;
        delete temp;
    }
};

int main() {
    ProductList productList;
    string productName;
    int productPrice;
    int ch;

    do {
        cout << "\n(1)insert\n(2)delete\n(3)print\n(4)exit\nEnter your choice: ";
        cin >>ch;
        cin.ignore();

        switch(ch) 
		{
            case 1:
            	{
                cout << "Enter product name: ";
                getline(cin, productName);
                cout << "Enter product price: ";
                cin >> productPrice;
                productList.insertProduct(productName, productPrice);
                break;
                }
				 
            case 2:
            	{
            		cout << "Enter product name to delete: ";
                    getline(cin, productName);
                    productList.deleteProduct(productName);
                    break;
				}
                
            case 3:
            	{
            		cout << "Product List:" << endl;
                    productList.displayProducts();
                    break;
				}
                
            case 4:
            	{
            		cout<<"Quitting...\n";
                    break;
				}
                
            default:
            	{
            		cout<<"Invalid option.Please try again.\n";
                    break;
				}
                
        }
    }while(ch!=4);

    return 0;
}

