#include <iostream>
using namespace std;

const int MAX_SIZE = 100;

class Queue 
{
	private:
    	int front, rear;
    	int arr[MAX_SIZE];

	public:
    	Queue() // Constructor
		{
        	front = rear = -1;
    	}

    
    void enqueue(int val) 
	{
        if (rear == MAX_SIZE - 1) 
		{
            cout << "Queue Overflow\n";
            return;
        }
        if (front == -1) 
		{
            front = rear = 0;
        } else 
		{
            rear++;
        }
        arr[rear] = val;
        cout << val << " enqueued into queue\n";
    }

    int dequeue() 
	{
        if (front == -1) 
		{
            cout << "Queue Underflow\n";
            return -1;
        }
        int val = arr[front];
        if (front == rear) 
		{
            front = rear = -1;
        } else 
		{
            front++;
        }
        return val;
    }

    int display() 
	{
        if (front == -1) 
		{
            cout << "Queue is empty\n";
            return -1;
        }
       for(int i=front;i<=rear;i++)
       {
       	 cout<<arr[i];
	   }
    }

	bool isEmpty() 
	{
        return front == -1;
    }
};

int main() 
{
    Queue queue;
    int choice, value;

    while (true) 
	{
        cout << "\nEnter your choice:\n";
        cout << "1. Enqueue\n";
        cout << "2. Dequeue\n";
        cout << "3. display\n";
        cout << "4. Exit\n";
        cin >> choice;

        switch (choice) 
		{
            case 1:
                cout << "Enter value to enqueue: ";
                cin >> value;
                queue.enqueue(value);
                break;
            case 2:
                cout << queue.dequeue() << " dequeued from queue\n";
                break;
            case 3:
                 queue.display() ;
                break;
            case 4:
                exit(0);
            default:
                cout << "Invalid choice\n";
        }
    }

    return 0;
}
