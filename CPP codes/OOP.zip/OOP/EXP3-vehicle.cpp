#include <iostream>
using namespace std;

class Vehicle {
private:
    int numWheels,maxSpeed,maxGears,curGear,curSpeed;
    string color;
    bool started,stopped;

public:
    Vehicle() : numWheels(4), color("Black"), maxSpeed(120), maxGears(5), curGear(1), curSpeed(0), started(false), stopped(true) {}

    Vehicle(int wheels, const std::string& clr, int maxSpd, int maxGrs)
        : numWheels(wheels), color(clr), maxSpeed(maxSpd), maxGears(maxGrs), curGear(1), curSpeed(0), started(false), stopped(true) {}

    int getWheels() const {
        return numWheels;
    }

    int getMaxGears() const {
        return maxGears;
    }

    int getMaxSpeed() const {
        return maxSpeed;
    }

    void setSpeed(int speed) {
        if (started && !stopped) {
            curSpeed = speed;
        } else {
            cout << "Start the vehicle first.\n";
        }
    }

    int getSpeed() const {
        return curSpeed;
    }

    string getColor() const {
        return color;
    }

    void start() {
        if (!started) {
            started = true;
            stopped = false;
            cout << "Vehicle started.\n";
        } else {
            cout << "Vehicle is already running.\n";
        }
    }

    void stop() {
        if (started && !stopped) {
            started = false;
            stopped = true;
            curSpeed = 0;
            curGear = 1;
            cout << "Vehicle stopped.\n";
        } else {
            cout << "Vehicle is not running.\n";
        }
    }

    void displayStatus() const {
        cout << "Current Speed: " << curSpeed << " km/h\n";
        cout << "Current Gear: " << curGear << "\n";
        cout << "Vehicle Status: " << (started ? "Running" : "Stopped") << "\n";
    }

    void increaseSpeed() {
        if (started && !stopped) {
            if (curSpeed < maxSpeed) {
                curSpeed += 10;
                cout << "Speed increased to " << curSpeed << " km/h.\n";
            } else {
                cout << "Maximum speed reached.\n";
            }
        } else {
            cout << "Start the vehicle first.\n";
        }
    }

    void decreaseSpeed() {
        if (started && !stopped) {
            if (curSpeed > 0) {
                curSpeed -= 10;
                cout << "Speed decreased to " << curSpeed << " km/h.\n";
            } else {
                cout << "Vehicle already stopped.\n";
            }
        } else {
            cout << "Start the vehicle first.\n";
        }
    }

    void nextGear() {
        if (started && !stopped) {
            if (curGear < maxGears) {
                curGear++;
                cout << "Shifted to gear " << curGear << ".\n";
            } else {
                cout << "Already in top gear.\n";
            }
        } else {
            cout << "Start the vehicle first.\n";
        }
    }

    void previousGear() {
        if (started && !stopped) {
            if (curGear > 1) {
                curGear--;
                cout << "Shifted to gear " << curGear << ".\n";
            } else {
               cout << "Already in first gear.\n";
            }
        } else {
            cout << "Start the vehicle first.\n";
        }
    }
};

int main() {
    Vehicle myCar;
    myCar.setSpeed(20);
    myCar.start();
    cout << "Number of Wheels: " << myCar.getWheels() << "\n";
    cout << "Maximum Speed: " << myCar.getMaxSpeed() << " km/h\n";
    cout << "Color: " << myCar.getColor() << "\n";
    int choice;
    do {
        cout << "\nMenu:\n";
        cout << "1. Increase Speed\n";
        cout << "2. Decrease Speed\n";
        cout << "3. Next Gear\n";
        cout << "4. Previous Gear\n";
        cout << "5. Start\n";
        cout << "6. Stop\n";
        cout << "7. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                myCar.increaseSpeed();
                break;
            case 2:
                myCar.decreaseSpeed();
                break;
            case 3:
                myCar.nextGear();
                break;
            case 4:
                myCar.previousGear();
                break;
            case 5:
                myCar.start();
                break;
            case 6:
                myCar.stop();
                break;
            case 7:
                cout << "Exiting...\n";
                break;
            default:
               cout << "Invalid choice. Try again.\n";
        }
        myCar.displayStatus();

    } while (choice != 7);

    return 0;
}
