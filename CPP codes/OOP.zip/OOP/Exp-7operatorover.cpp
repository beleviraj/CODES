#include<iostream>
using namespace std;

class complex
{
	private:
		int real;
		int imag;
		
	public:
		complex(int r=0,int i=0)
		{
			real=r;
			imag=i;
		}
		
		void setreal(int r)
		{
			real=r;
		}
		
		int getreal()
		{
			return real;
		}
		
		void setimag(int i)
		{
			imag=i;
		}
		
		int getimag()
		{
			return imag;
		}
		
		complex operator +(complex obj)
		{
			complex x;
			x.real = real + obj.real;
			x.imag = imag + obj.imag;
			return x;
		}
			complex operator -(complex obj)
		{
			complex x;
			x.real = real - obj.real;
			x.imag = imag - obj.imag;
			return x;
		}
		
		void print()
		{
			cout<<"complex no. = "<<getreal()<<"+"<<getimag()<<"i"<<endl;
		}
		
};

int main()
{
	int real1,real2,imag1,imag2;
	
	cout<<"enter the real and imaginary part of the first complex number:";
	cin>>real1>>imag1;
	
	cout<<"enter the real and imaginary part of the second complex number:";
	cin>>real2>>imag2;
	
	complex c1(real1,imag1);
	complex c2(real2,imag2);
	
	complex  sum=c1+c2;
	complex  diff = c1-c2;
	
	cout<<"sum:"<<endl;
	sum.print();
	
	cout<<"differeance:"<<endl;
	diff.print();
	
	return 0;
}