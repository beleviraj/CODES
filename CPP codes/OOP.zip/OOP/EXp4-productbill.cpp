#include<bits/stdc++.h>
using namespace std;
struct product{
    int id;
    char name[20];
    int price;
    int gst;
};
void insert(int i,product P[]){
    cout<<"\nEnter id, name, price and GST of product :";
    cin>>P[i].id>>P[i].name>>P[i].price>>P[i].gst;
}
int Delete(product P[],int i){
    char nm[20];
    int s,j,t;
    cout<<"Enter name of product : ";
    cin>>nm;
    for( j=0;j<i;j++){
        s=strcmp(P[j].name,nm);
        if(s==0) {
            for ( t=j; t < i ; t++)
            {
                P[t]=P[t+1];
            }
            return 1;
        }
    }
    return 0;
}
void search(product P[],int i){
    char nm[20];
    int s,t,j;
    cout<<"\nEnter name of product :";
    cin>>nm;
    for( j=0;j<i;j++){
        s=strcmp(P[j].name,nm);
        if(s==0) {
            cout<<"\nProduct found...\n";
            cout<<"SR No."<<"\t\t"<<"ID"<<"\t\t"<<"Name"<<"\t\t"<<"price(Rs)"<<"\t\t"<<"gst(%)"<<endl<<endl;
            cout<<j+1<<"\t\t"<<P[j].id<<"\t\t"<<P[j].name<<"\t\t"<<P[j].price<<"\t\t\t"<<P[j].gst<<endl;
            return;
        }

    }
    cout<<"\nProduct not found";
}
void display(product P[],int i)
{
    
    cout<<"SR No."<<"\t\t"<<"ID"<<"\t\t"<<"Name"<<"\t\t"<<"price(Rs)"<<"\t\t"<<"gst(%)"<<endl<<endl;
    for(int j=0;j<i;j++){
        cout<<j+1<<"\t\t"<<P[j].id<<"\t\t"<<P[j].name<<"\t\t"<<P[j].price<<"\t\t\t"<<P[j].gst<<endl;
    }
}
int main(){
    product P[100];
    int ch=4,i=0,r;
    while (ch)
    {
        cout<<"\n0.Exit\t1.Insert\t2.Delete\t3.Search\n4.Display";
        cout<<"\nEnter your choice :";
        cin>>ch;
        switch (ch)
        {
        case 0: cout<<"\nExited";
            break;
        case 1: insert(i,P);
                i++;
                break;
        case 2:r=Delete(P,i);
                if(r==1){
                    cout<<"\nProduct deleted successfully..";
                    i--;
                }
                else cout<<"\nProduct not found";
                break;
        case 3: search(P,i);
                break;        
        case 4: display(P,i);
                break;        
        default: cout<<"\nEnter valid choice...";
            break;
        }
    }
    
    return 0;
}
